from pathlib import Path
import collections,csv,os,statistics
import matplotlib
matplotlib.use('Agg')
from matplotlib import pyplot as plt
from matplotlib.ticker import FixedLocator, FixedFormatter,MaxNLocator
p=Path(__file__).resolve().parent
year=int(os.environ.get('CACTUS_YEAR',2024))
if year==2026:p=p/'mc2026'
modes={'stock':('Upstream Ganak','#5b6676','--','s'),'previous':('Previous ordering','#c06420','-.','^'),'pushed':('Pushed ordering','#007667','-','o')}
def read(f):
 with f.open() as stream:return list(csv.DictReader(stream))
rows=read(p/'runs.csv')
assert len(rows)==600
indexed=collections.defaultdict(dict)
for r in rows:
 i=int(r['id']);m=r['mode'];assert m not in indexed[i] and r['status'] in ('solved','timeout','memory')
 indexed[i][m]=r
assert set(indexed)==set(range(200))
for i,v in indexed.items():
 assert v.keys()==modes.keys() and len({r['cpu'] for r in v.values()})==1
 assert len({r['count'] for r in v.values() if r['status']=='solved'})<=1
hist={} if year!=2024 else {int(r['id']):r['count'] for r in read(Path('/tmp/gbench/heur/full_tracks.csv')) if r['year']=='2024' and r['status']=='solved'}
for r in rows:
 if r['status']=='solved' and int(r['id']) in hist:assert r['count']==hist[int(r['id'])]
if year==2026:
 reference={int(r['id']):r['count'] for r in read(p/'competition_counts.csv')}
 overlap={int(r['id']) for r in rows if r['status']=='solved' and int(r['id']) in reference}
 for r in rows:
  if r['status']=='solved' and int(r['id']) in reference:
   assert r['count']==reference[int(r['id'])], (r['id'],r['mode'])
 print('MC2026 solved inputs with published exact counts:',len(overlap),flush=True)
times={m:sorted(float(r['wall']) for r in rows if r['mode']==m and r['status']=='solved') for m in modes}
assert all(0<t<=45.1 for a in times.values() for t in a)
sets={m:{i for i,v in indexed.items() if v[m]['status']=='solved'} for m in modes}
with (p/'summary.csv').open('w') as f:
 w=csv.writer(f);w.writerow(['mode','solved','timeouts','memory','PAR2_s','gain_vs_previous','loss_vs_previous'])
 for m in modes:
  cases=[v[m] for v in indexed.values()];w.writerow([m,len(sets[m]),sum(r['status']=='timeout' for r in cases),sum(r['status']=='memory' for r in cases),round((sum(times[m])+90*(200-len(times[m])))/200,4),' '.join(map(str,sorted(sets[m]-sets['previous']))),' '.join(map(str,sorted(sets['previous']-sets[m])))])
common=sets['previous']&sets['pushed']; meaningful=[indexed[i] for i in common if max(float(indexed[i][m]['wall']) for m in ('previous','pushed'))>=1]
if meaningful:print('common >=1s',len(meaningful),'median previous/pushed',statistics.median(float(v['previous']['wall'])/float(v['pushed']['wall']) for v in meaningful))
print((p/'summary.csv').read_text())
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':11,'axes.labelsize':12,'svg.fonttype':'none','pdf.fonttype':42})
fig,ax=plt.subplots(figsize=(9.4,5.8))
fig.subplots_adjust(left=.115,right=.965,bottom=.175,top=.835)
fig.suptitle(f'MC{year} model counting',x=.115,y=.967,ha='left',fontsize=20,fontweight='bold')
fig.text(.115,.88,'All 200 unweighted Track 1 instances  ·  45-second cutoff',color='#46515e',fontsize=12)
ax.axhline(45,color='#83909a',ls=':',lw=1)
for mode,(name,color,style,marker) in modes.items():
 a=times[mode];n=len(a)
 ax.plot(range(1,n+1),a,label=f'{name}  ({n})',c=color,ls=style,lw=2.25 if mode=='pushed' else 1.85,zorder=4 if mode=='pushed' else 3)
 ax.plot([n],[a[-1]],color=color,marker=marker,ms=6,linestyle='none',zorder=6)
ax.set(xlabel='Number of instances solved',ylabel='Wall time per instance (seconds)',yscale='log',xlim=(0,max(map(len,times.values()))+3),ylim=(max(.001,min(a[0] for a in times.values())*.72),65))
ticks=[.001,.003,.01,.03,.1,.3,1,3,10,45];ticks=[v for v in ticks if v>=ax.get_ylim()[0]]
ax.yaxis.set_major_locator(FixedLocator(ticks));ax.yaxis.set_major_formatter(FixedFormatter([f'{v:g}' for v in ticks]));ax.minorticks_off()
ax.xaxis.set_major_locator(MaxNLocator(integer=True,nbins=9))
ax.grid(axis='y',color='#dae0e5',linewidth=.7);ax.spines[['top','right']].set_visible(False)
for s in ('bottom','left'):ax.spines[s].set_color('#9ba7ac')
ax.legend(loc='upper left',bbox_to_anchor=(0,.91),frameon=False,fontsize=10,handlelength=3.4)
fig.text(.115,.035,'Each curve ranks its own solved instances by runtime. Lower is faster; farther right means more solved.',fontsize=9,color='#46515e')
for ext in ('png','pdf'):fig.savefig(p/f'mc{year}-ordering-cactus.{ext}',dpi=200,facecolor='white')
