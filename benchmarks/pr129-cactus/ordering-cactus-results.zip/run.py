from benchmark import run_case,FIELDS
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor,as_completed
from multiprocessing import Queue
import os,csv,random
year=int(os.environ.get('CACTUS_YEAR','2024'))
assert year in (2024,2026)
p=Path(__file__).resolve().parent
if year==2026:p=p/'mc2026'
d=Path('/tmp/gbench')
builds={'stock':(d/'stockbuild/ganak',str(d/'stockbuild/lib')),'previous':(d/'finalbuild/ganak',str(d/'finalbuild/lib')),'pushed':(d/'finalbuild/ganak',str(d/'order-release'))}
def init(q):
 global core
 core=q.get()
def work(src):
 i=int(src.name.split('.')[0][-3:])
 return run_case((year,i,src,core,0,45,builds,3))
if __name__=='__main__':
 paths=sorted((d/f'mc{year}-track1-mc_competition').glob('*.cnf.xz'));assert [int(x.name.split('.')[0][-3:]) for x in paths]==list(range(200))
 random.Random(49261).shuffle(paths)
 q=Queue();cores=sorted(os.sched_getaffinity(0))
 for c in cores:q.put(c)
 fn=p/'runs.csv';done=set()
 if fn.exists():
  with fn.open() as f:
   for r in csv.DictReader(f):done.add((int(r['id']),r['mode']))
 with fn.open('a') as f, ProcessPoolExecutor(len(cores),initializer=init,initargs=(q,)) as pool:
  w=csv.writer(f)
  if not f.tell():w.writerow(FIELDS);f.flush()
  tasks=[pool.submit(work,src) for src in paths if any((int(src.name.split('.')[0][-3:]),m) not in done for m in builds)]
  for task in as_completed(tasks):
   for r in task.result():
    if (r[1],r[4]) not in done:w.writerow(r)
   f.flush()
