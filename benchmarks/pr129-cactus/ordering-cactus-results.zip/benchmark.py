"""Linux, Python 3.10+. Benchmark three independent Ganak builds on unpacked Track 1 inputs."""
import argparse
import csv
import hashlib
import lzma
import os
from pathlib import Path
import random
import re
import resource
import shutil
import signal
import subprocess
import tempfile
import time
from concurrent.futures import ProcessPoolExecutor

FIELDS = 'year id rep cpu mode limit status wall cpu_seconds rss_kib count'.split()

def run_case(job):
    year, instance, source, core, repetition, cutoff, builds, memory_gib = job
    os.sched_setaffinity(0, {core})
    resource.setrlimit(resource.RLIMIT_AS, (memory_gib << 30, memory_gib << 30))
    resource.setrlimit(resource.RLIMIT_CORE, (0, 0))
    order = list(builds)
    random.Random(110937 + year * 91 + instance).shuffle(order)
    if repetition % 2:
        order.reverse()
    results = []
    answers = set()
    with tempfile.TemporaryDirectory() as directory:
        cnf = Path(directory) / 'input.cnf'
        with lzma.open(source) as compressed, cnf.open('wb') as plain:
            shutil.copyfileobj(compressed, plain)
        for mode in order:
            exe, libraries = builds[mode]
            env = os.environ.copy()
            if libraries:
                env['LD_LIBRARY_PATH'] = libraries + ':' + env.get('LD_LIBRARY_PATH', '')
            command = [exe, '--threads', '1', '--prob', '0', '--verb', '1']
            if mode != 'stock':
                command += ['--frontierstates', '8192', '--groupedsweep', '0']
            with tempfile.TemporaryFile(dir=directory) as log:
                started = time.monotonic()
                with subprocess.Popen(command + [cnf], env=env, stdout=log, stderr=subprocess.STDOUT) as process:
                    expired = False
                    def on_timeout(*args):
                        nonlocal expired
                        expired = True
                        process.kill()
                    old_handler = signal.signal(signal.SIGALRM, on_timeout)
                    signal.alarm(cutoff)
                    try:
                        _, status, usage = os.wait4(process.pid, 0)
                    finally:
                        signal.alarm(0)
                        signal.signal(signal.SIGALRM, old_handler)
                    process.returncode = os.waitstatus_to_exitcode(status)
                elapsed = time.monotonic() - started
                log.seek(0)
                text = log.read().decode(errors='replace')
            exact = re.search(r'^c s exact arb int (\d+)\s*$', text, re.M)
            if expired:
                state = 'timeout'
            elif exact and process.returncode in (0, 10, 20):
                state = 'solved'
            elif re.search(r'bad_alloc|out of memory|cannot allocate memory|bad_array_new_length', text, re.I):
                state = 'memory'
            else:
                raise RuntimeError(f'{year}/{instance:03} {mode} exited {process.returncode}\n{text[-2000:]}')
            count = exact[1] if state == 'solved' else ''
            if count:
                answers.add(count)
            results.append([year, instance, repetition, core, mode, cutoff, state, round(elapsed,5),
                            round(usage.ru_utime + usage.ru_stime,5), usage.ru_maxrss, count])
    if len(answers) > 1:
        raise RuntimeError(f'Exact counts disagree on {year}/{instance:03}')
    return results

def lane(jobs):
    return [row for job in jobs for row in run_case(job)]

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ('stock', 'pr', 'new'):
        parser.add_argument('--' + name, required=True, type=Path, help='Path to the Ganak binary')
        parser.add_argument('--' + name + '-libs', default='', help='Optional LD_LIBRARY_PATH prefix for this build')
    parser.add_argument('--data24', type=Path)
    parser.add_argument('--data23', type=Path)
    parser.add_argument('--ids', help='Comma-separated input IDs; all available IDs by default')
    parser.add_argument('--cpus', default=','.join(map(str, sorted(os.sched_getaffinity(0)))))
    parser.add_argument('--rep', type=int, default=0)
    parser.add_argument('--cap24', type=int, default=300)
    parser.add_argument('--cap23', type=int, default=45)
    parser.add_argument('--memory-gib', type=int, default=3)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    if not args.data24 and not args.data23:
        parser.error('Supply --data24 or --data23')
    if args.out.exists():
        parser.error('Choose a new output CSV')
    cpus = list(map(int, args.cpus.split(',')))
    ids = set(map(int, args.ids.split(','))) if args.ids else None
    builds = {k: (str(getattr(args, k).resolve(strict=True)), getattr(args, k + '_libs')) for k in ('stock', 'pr', 'new')}
    jobs = []
    for year, folder, cap in [(2024, args.data24, args.cap24), (2023, args.data23, args.cap23)]:
        if folder is None:
            continue
        sources = sorted(folder.glob('*_track1_*.cnf.xz'))
        if not sources:
            parser.error(f'No Track 1 CNFs in {folder}')
        random.Random(1300 + year).shuffle(sources)
        for source in sources:
            number = int(source.name.split('.')[0][-3:])
            if ids is None or number in ids:
                jobs.append((year, number, source, cpus[len(jobs) % len(cpus)], args.rep, cap, builds, args.memory_gib))
    # Static assignment gives each CPU its own queue and all three builds the same
    # core per case. The original machine-specific runner used a dynamic work queue.
    with ProcessPoolExecutor(len(cpus)) as pool, args.out.open('x') as output:
        writer = csv.writer(output)
        writer.writerow(FIELDS)
        for completed in pool.map(lane, [jobs[j::len(cpus)] for j in range(len(cpus))]):
            writer.writerows(completed)
            output.flush()
