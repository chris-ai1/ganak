from run import *
from collections import defaultdict
from benchmark import FIELDS
def retry(job):
 i,core=job
 path=d/f'mc{year}-track1-mc_competition'/f'mc{year}_track1_{i:03}.cnf.xz'
 return run_case((year,i,path,core,1,45,builds,3))
def lane_repeat(jobs):return [r for job in jobs for r in retry(job)]
if __name__=='__main__':
 with (p/'runs.csv').open() as f:rs=list(csv.DictReader(f))
 assert len(rs)==600
 data=defaultdict(dict)
 for r in rs:data[int(r['id'])][r['mode']]=r
 comparisons=tuple(builds) if year==2026 else ('previous','pushed')
 jobs=[(i,int(v['pushed']['cpu'])) for i,v in data.items() if len({v[m]['status'] for m in comparisons})>1]
 lanes=defaultdict(list)
 for job in jobs:lanes[job[1]].append(job)
 with (p/'repeats.csv').open('w') as f,ProcessPoolExecutor(max(1,len(lanes))) as pool:
  w=csv.writer(f);w.writerow(FIELDS)
  for rr in pool.map(lane_repeat,lanes.values()):
   for row in rr:
    ct=data[row[1]];answers={r['count'] for r in ct.values() if r['count']}
    assert not row[-1] or not answers or row[-1] in answers
    print(row[1],row[4],row[6],row[7],flush=True);w.writerow(row)
